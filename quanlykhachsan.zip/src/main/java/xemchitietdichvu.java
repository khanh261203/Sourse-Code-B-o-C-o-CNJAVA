import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.text.SimpleDateFormat;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/xemchitietdichvu")
public class xemchitietdichvu extends HttpServlet {
    private static final long serialVersionUID = 1L;

    public xemchitietdichvu() {
        super();
    }

    protected void doGet(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
    	res.setContentType("text/html; charset=UTF-8");
    	PrintWriter out = res.getWriter();
        res.setContentType("text/html");
        out.println("<html>"
                + "<head><link rel='stylesheet' type='text/css' href='style.css'/></head>"
                + "<body>");

        try {
            Class.forName("com.mysql.jdbc.Driver");
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/quanlykhachsan", "root", "");
            Statement stmt = con.createStatement();
            String sql = "SELECT * FROM chitietdichvu";

            ResultSet rs = stmt.executeQuery(sql);
            out.println("<table border=1 width=50% height=50%>");
            out.println("<tr><th>MaChiTiet</th><th>SoThuTuThue</th><th>MaDichVu</th><th>NgayThucHienDichVu</th><th>SoLuong</th></tr>");

            SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

            while (rs.next()) {
                String maChiTiet = rs.getString("MaChiTiet");
                int soThuTuThue = rs.getInt("SoThuTuThue");
                String maDichVu = rs.getString("MaDichVu");
                String ngayThucHienDichVu = dateFormat.format(rs.getTimestamp("NgayThucHienDichVu"));
                int soLuong = rs.getInt("SoLuong");

                out.println("<tr><td>" + maChiTiet + "</td><td>" + soThuTuThue + "</td><td>" + maDichVu + "</td><td>" + ngayThucHienDichVu + "</td><td>" + soLuong + "</td></tr>");
            }

            out.println("</table>");
            out.println("</body></html>");
            con.close();
        } catch (Exception e) {
            out.println("error");
            e.printStackTrace(); // In chi tiết lỗi ra console để dễ theo dõi và sửa lỗi
        }
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doGet(request, response);
    }
}
