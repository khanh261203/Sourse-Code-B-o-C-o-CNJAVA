import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/xemtanglau")
public class xemtanglau extends HttpServlet {
    private static final long serialVersionUID = 1L;

    public xemtanglau() {
        super();
    }

    protected void doGet(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
    	res.setContentType("text/html; charset=UTF-8");
    	PrintWriter out = res.getWriter();
        res.setContentType("text/html");
        out.println("<html>"
                + "<link rel='stylesheet' type='text/css' href='style.css'/>"
                + "<body>");

        try {
            Class.forName("com.mysql.jdbc.Driver");
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/quanlykhachsan", "root", "");
            Statement stmt = con.createStatement();
            String sql = "select * from tanglau";

            ResultSet rs = stmt.executeQuery(sql);
            out.println("<table border=1 width=50% height=50%>");
            out.println("<tr><th>STTTang</th><th>TenTang</th></tr>");

            while (rs.next()) {
                int sttTang = rs.getInt("STTTang");
                String tenTang = rs.getString("TenTang");

                out.println("<tr><td>" + sttTang + "</td><td>" + tenTang + "</td></tr>");
            }

            out.println("</table>");
            out.println("</html></body>");
            con.close();
        } catch (Exception e) {
            out.println("error");
        }
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doGet(request, response);
    }
}
