import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/themphong")
public class themphong extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();

        int soPhong = Integer.parseInt(request.getParameter("soPhong"));
        int tangLau = Integer.parseInt(request.getParameter("tangLau"));
        String maLoaiPhong = request.getParameter("maLoaiPhong");

        try {
            // Kết nối đến cơ sở dữ liệu (sử dụng JDBC)
            Class.forName("com.mysql.jdbc.Driver");
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/quanlykhachsan", "root", "");

            // Sử dụng PreparedStatement để thêm dữ liệu vào bảng phong
            String sql = "INSERT INTO phong (SoPhong, TangLau, MaLoaiPhong) VALUES (?, ?, ?)";
            try (PreparedStatement pstmt = con.prepareStatement(sql)) {
                pstmt.setInt(1, soPhong);
                pstmt.setInt(2, tangLau);
                pstmt.setString(3, maLoaiPhong);

                pstmt.executeUpdate();
            }

            // Đóng kết nối
            con.close();

            // Chuyển hướng sau khi thêm thành công
            response.sendRedirect("xemphong");
        } catch (Exception e) {
            e.printStackTrace();
            out.println("Error: " + e.getMessage());
        }
    }
}
