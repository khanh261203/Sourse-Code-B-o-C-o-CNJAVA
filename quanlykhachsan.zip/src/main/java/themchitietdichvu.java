import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.Timestamp;
import java.text.ParseException;
import java.text.SimpleDateFormat;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/themchitietdichvu")
public class themchitietdichvu extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();

        String maChiTiet = request.getParameter("maChiTiet");
        int soThuTuThue = Integer.parseInt(request.getParameter("soThuTuThue"));
        String maDichVu = request.getParameter("maDichVu");
        
        // Đọc ngày thực hiện từ form và chuyển đổi về định dạng Timestamp
        String ngayThucHienString = request.getParameter("ngayThucHien");
        Timestamp ngayThucHien = convertStringToTimestamp(ngayThucHienString);
        
        int soLuong = Integer.parseInt(request.getParameter("soLuong"));

        try {
            // Kết nối đến cơ sở dữ liệu (sử dụng JDBC)
            Class.forName("com.mysql.jdbc.Driver");
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/quanlykhachsan", "root", "");

            // Sử dụng PreparedStatement để thêm dữ liệu vào bảng chitietdichvu
            String sql = "INSERT INTO chitietdichvu (MaChiTiet, SoThuTuThue, MaDichVu, NgayThucHienDichVu, SoLuong) VALUES (?, ?, ?, ?, ?)";
            try (PreparedStatement pstmt = con.prepareStatement(sql)) {
                pstmt.setString(1, maChiTiet);
                pstmt.setInt(2, soThuTuThue);
                pstmt.setString(3, maDichVu);
                pstmt.setTimestamp(4, ngayThucHien);
                pstmt.setInt(5, soLuong);

                pstmt.executeUpdate();
            }

            // Đóng kết nối
            con.close();

            // Chuyển hướng sau khi thêm thành công
            response.sendRedirect("xemchitietdichvu");
        } catch (Exception e) {
            e.printStackTrace();
            out.println("Error: " + e.getMessage());
        }
    }

    // Hàm chuyển đổi String sang Timestamp
    private Timestamp convertStringToTimestamp(String dateString) {
        try {
            SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm");
            java.util.Date parsedDate = dateFormat.parse(dateString);
            return new Timestamp(parsedDate.getTime());
        } catch (ParseException e) {
            e.printStackTrace();
            return null;
        }
    }
}
