import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/themloaiphong")
public class themloaiphong extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();

        String maLoaiPhong = request.getParameter("maLoaiPhong");
        boolean coMayLanh = Boolean.parseBoolean(request.getParameter("coMayLanh"));
        boolean coTV = Boolean.parseBoolean(request.getParameter("coTV"));
        boolean coMayNuocNong = Boolean.parseBoolean(request.getParameter("coMayNuocNong"));
        boolean coTuLanh = Boolean.parseBoolean(request.getParameter("coTuLanh"));
        double giaThue1Ngay = Double.parseDouble(request.getParameter("giaThue1Ngay"));
        double giaThue1Tuan = Double.parseDouble(request.getParameter("giaThue1Tuan"));

        try {
            // Kết nối đến cơ sở dữ liệu (sử dụng JDBC)
            Class.forName("com.mysql.jdbc.Driver");
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/quanlykhachsan", "root", "");

            // Sử dụng PreparedStatement để thêm dữ liệu vào bảng loaiphong
            String sql = "INSERT INTO loaiphong (MaLoaiPhong, CoMayLanh, CoTV, CoMayNuocNong, CoTuLanh, GiaThue1Ngay, GiaThue1Tuan) VALUES (?, ?, ?, ?, ?, ?, ?)";
            try (PreparedStatement pstmt = con.prepareStatement(sql)) {
                pstmt.setString(1, maLoaiPhong);
                pstmt.setBoolean(2, coMayLanh);
                pstmt.setBoolean(3, coTV);
                pstmt.setBoolean(4, coMayNuocNong);
                pstmt.setBoolean(5, coTuLanh);
                pstmt.setDouble(6, giaThue1Ngay);
                pstmt.setDouble(7, giaThue1Tuan);

                pstmt.executeUpdate();
            }

            // Đóng kết nối
            con.close();

            // Chuyển hướng sau khi thêm thành công
            response.sendRedirect("xemloaiphong");
        } catch (Exception e) {
            e.printStackTrace();
            out.println("Error: " + e.getMessage());
        }
    }
}
