import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/themdichvu")
public class themdichvu extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();

        // Đảm bảo mã hóa UTF-8 cho request
        request.setCharacterEncoding("UTF-8");

        String maDichVu = request.getParameter("maDichVu");
        String tenDichVu = request.getParameter("tenDichVu");
        String donViTinh = request.getParameter("donViTinh");
        int dinhLuong = Integer.parseInt(request.getParameter("dinhLuong"));
        double donGia = Double.parseDouble(request.getParameter("donGia"));
        String ghiChu = request.getParameter("ghiChu");

        try {
            // Kết nối đến cơ sở dữ liệu (sử dụng JDBC)
            Class.forName("com.mysql.jdbc.Driver");
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/quanlykhachsan?characterEncoding=UTF-8", "root", "");

            // Sử dụng PreparedStatement để thêm dữ liệu vào bảng dichvu
            String sql = "INSERT INTO dichvu (MaDichVu, TenDichVu, DonViTinh, DinhLuong, DonGia, GhiChu) VALUES (?, ?, ?, ?, ?, ?)";
            try (PreparedStatement pstmt = con.prepareStatement(sql)) {
                pstmt.setString(1, maDichVu);
                pstmt.setString(2, tenDichVu);
                pstmt.setString(3, donViTinh);
                pstmt.setInt(4, dinhLuong);
                pstmt.setDouble(5, donGia);
                pstmt.setString(6, ghiChu);

                pstmt.executeUpdate();
            }

            // Đóng kết nối
            con.close();

            // Chuyển hướng sau khi thêm thành công
            response.sendRedirect("xemdichvu");
        } catch (Exception e) {
            e.printStackTrace();
            out.println("Error: " + e.getMessage());
        }
    }
}
