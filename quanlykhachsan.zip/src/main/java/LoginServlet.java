import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet("/LoginServlet")
public class LoginServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();

        String username = request.getParameter("username");
        String password = request.getParameter("password");

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/quanlykhachsan", "root", "");

            PreparedStatement ps = con.prepareStatement("SELECT * FROM user WHERE username=? AND password=?");
            ps.setString(1, username);
            ps.setString(2, password);

            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                // Đăng nhập thành công
                HttpSession session = request.getSession();
                session.setAttribute("username", username);
                response.sendRedirect("Home.html");
            } else {
                // Đăng nhập thất bại
                out.println("<html><head><title>Login Failed</title></head><body>");
                out.println("<h2 style='color: #ff0000;'>Login Failed</h2>");
                out.println("<p>Username or password is incorrect. Please try again.</p>");
                out.println("<a href='Login.html'>Back to Login</a>");
                out.println("</body></html>");
            }

            con.close();
        } catch (Exception e) {
            out.println("<html><head><title>Error</title></head><body>");
            out.println("<h2 style='color: #ff0000;'>Error</h2>");
            out.println("<p>An error occurred: " + e.getMessage() + "</p>");
            out.println("</body></html>");
            e.printStackTrace();
        }

        out.close();
    }
}
