import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.text.SimpleDateFormat;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/xemthuephong")
public class xemthuephong extends HttpServlet {
    private static final long serialVersionUID = 1L;

    public xemthuephong() {
        super();
    }

    protected void doGet(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
        res.setContentType("text/html; charset=UTF-8");
        PrintWriter out = res.getWriter();
        res.setContentType("text/html");
        out.println("<html>"
                + "<head><link rel='stylesheet' type='text/css' href='style.css'/></head>"
                + "<body>");

        try {
            Class.forName("com.mysql.jdbc.Driver");
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/quanlykhachsan", "root", "");
            Statement stmt = con.createStatement();
            String sql = "SELECT * FROM thuephong";

            ResultSet rs = stmt.executeQuery(sql);
            out.println("<table border=1 width=50% height=50%>");
            out.println("<tr><th>SoThuTuThue</th><th>SoPhong</th><th>MaKhach</th><th>NgayNhanPhong</th><th>NgayTraPhong</th><th>TongTienPhong</th><th>TongTienDichVu</th></tr>");

            SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

            while (rs.next()) {
                int soThuTuThue = rs.getInt("SoThuTuThue");
                int soPhong = rs.getInt("SoPhong");
                String maKhach = rs.getString("MaKhach");
                String ngayNhanPhong = dateFormat.format(rs.getTimestamp("NgayNhanPhong"));
                String ngayTraPhong = dateFormat.format(rs.getTimestamp("NgayTraPhong"));
                double tongTienPhong = rs.getDouble("TongTienPhong");
                double tongTienDichVu = rs.getDouble("TongTienDichVu");

                out.println("<tr><td>" + soThuTuThue + "</td><td>" + soPhong + "</td><td>" + maKhach + "</td><td>" + ngayNhanPhong + "</td><td>" + ngayTraPhong + "</td><td>" + tongTienPhong + "</td><td>" + tongTienDichVu + "</td></tr>");
            }

            out.println("</table>");
            out.println("</body></html>");
            con.close();
        } catch (Exception e) {
            out.println("error");
            e.printStackTrace();
        }
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doGet(request, response);
    }
}
