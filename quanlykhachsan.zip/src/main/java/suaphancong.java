import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/SuaPhanCongServlet")
public class suaphancong extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();

        String maNhanVien = request.getParameter("maNhanVien");
        String ngayStr = request.getParameter("ngay");
        String ca = request.getParameter("ca");
        int tangLau = Integer.parseInt(request.getParameter("tangLau"));

        try {
            // Kết nối đến cơ sở dữ liệu (sử dụng JDBC)
            Class.forName("com.mysql.jdbc.Driver");
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/quanlykhachsan", "root", "");

            // Chuyển định dạng chuỗi ngày sang kiểu java.sql.Timestamp
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm");
            Date ngayDate = sdf.parse(ngayStr);
            java.sql.Timestamp ngay = new java.sql.Timestamp(ngayDate.getTime());

            // Sử dụng PreparedStatement để cập nhật dữ liệu trong bảng phancong
            String sql = "UPDATE phancong SET Ngay=?, Ca=?, TangLau=? WHERE MaNhanVien=?";
            try (PreparedStatement pstmt = con.prepareStatement(sql)) {
                pstmt.setTimestamp(1, ngay);
                pstmt.setString(2, ca);
                pstmt.setInt(3, tangLau);
                pstmt.setString(4, maNhanVien);

                pstmt.executeUpdate();
            }

            // Đóng kết nối
            con.close();

            // Chuyển hướng sau khi cập nhật thành công
            response.sendRedirect("xemphancong");
        } catch (Exception e) {
            e.printStackTrace();
            out.println("Error: " + e.getMessage());
        }
    }
}
