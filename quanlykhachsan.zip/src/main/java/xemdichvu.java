import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/xemdichvu")
public class xemdichvu extends HttpServlet {
    private static final long serialVersionUID = 1L;

    public xemdichvu() {
        super();
    }

    protected void doGet(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
    	 res.setContentType("text/html; charset=UTF-8");
        PrintWriter out = res.getWriter();
        res.setContentType("text/html");
        out.println("<html>"
                + "<link rel='stylesheet' type='text/css' href='style.css'/>"
                + "<body>");

        try {
            Class.forName("com.mysql.jdbc.Driver");
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/quanlykhachsan", "root", "");
            Statement stmt = con.createStatement();
            String sql = "select * from dichvu";

            ResultSet rs = stmt.executeQuery(sql);
            out.println("<table border=1 width=50% height=50%>");
            out.println("<tr><th>MaDichVu</th><th>TenDichVu</th><th>DonViTinh</th><th>DinhLuong</th><th>DonGia</th><th>GhiChu</th></tr>");

            while (rs.next()) {
                String maDichVu = rs.getString("MaDichVu");
                String tenDichVu = rs.getString("TenDichVu");
                String donViTinh = rs.getString("DonViTinh");
                int dinhLuong = rs.getInt("DinhLuong");
                double donGia = rs.getInt("DonGia");
                String ghiChu = rs.getString("GhiChu");

                out.println("<tr><td>" + maDichVu + "</td><td>" + tenDichVu + "</td><td>" + donViTinh + "</td><td>" + dinhLuong + "</td><td>" + donGia + "</td><td>" + ghiChu + "</td></tr>");
            }

            out.println("</table>");
            out.println("</html></body>");
            con.close();
        } catch (Exception e) {
            out.println("error");
        }
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doGet(request, response);
    }
}


