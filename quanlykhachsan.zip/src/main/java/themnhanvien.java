import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/themnhanvienphucvu")
public class themnhanvien extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();

        String maNhanVien = request.getParameter("maNhanVien");
        String hoTenNV = request.getParameter("hoTenNV");
        boolean gioiTinh = Boolean.parseBoolean(request.getParameter("gioiTinh"));
        String diaChi = request.getParameter("diaChi");
        String soDienThoai = request.getParameter("soDienThoai");

        try {
            Class.forName("com.mysql.jdbc.Driver");
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/quanlykhachsan", "root", "");

            String sql = "INSERT INTO nhanvienphucvu (MaNhanVien, HoTenNV, GioiTinh, DiaChi, SoDienThoai) VALUES (?, ?, ?, ?, ?)";
            try (PreparedStatement pstmt = con.prepareStatement(sql)) {
                pstmt.setString(1, maNhanVien);
                pstmt.setString(2, hoTenNV);
                pstmt.setBoolean(3, gioiTinh);
                pstmt.setString(4, diaChi);
                pstmt.setString(5, soDienThoai);

                pstmt.executeUpdate();
            }

            con.close();

            response.sendRedirect("xemnhanvienphucvu");
        } catch (Exception e) {
            e.printStackTrace();
            out.println("Error: " + e.getMessage());
        }
    }
}
