import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/xemnhanvienphucvu")
public class xemnhanvien extends HttpServlet {
    private static final long serialVersionUID = 1L;

    public xemnhanvien() {
        super();
    }

    protected void doGet(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
        res.setContentType("text/html; charset=UTF-8");
        PrintWriter out = res.getWriter();
        res.setContentType("text/html");
        out.println("<html>"
                + "<link rel='stylesheet' type='text/css' href='style.css'/>"
                + "<body>");

        try {
            Class.forName("com.mysql.jdbc.Driver");
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/quanlykhachsan", "root", "");
            Statement stmt = con.createStatement();
            String sql = "select * from nhanvienphucvu";

            ResultSet rs = stmt.executeQuery(sql);
            out.println("<table border=1 width=50% height=50%>");
            out.println("<tr><th>MaNhanVien</th><th>HoTenNV</th><th>GioiTinh</th><th>DiaChi</th><th>SoDienThoai</th></tr>");

            while (rs.next()) {
                String maNhanVien = rs.getString("MaNhanVien");
                String hoTenNV = rs.getString("HoTenNV");
                boolean gioiTinh = rs.getBoolean("GioiTinh");
                String gioiTinhStr = gioiTinh ? "Nam" : "Nữ"; 

                String diaChi = rs.getString("DiaChi");
                String soDienThoai = rs.getString("SoDienThoai");

                out.println("<tr><td>" + maNhanVien + "</td><td>" + hoTenNV + "</td><td>" + gioiTinhStr + "</td><td>" + diaChi + "</td><td>" + soDienThoai + "</td></tr>");
            }

            out.println("</table>");
            out.println("</html></body>");
            con.close();
        } catch (Exception e) {
            out.println("error");
        }
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doGet(request, response);
    }
}
