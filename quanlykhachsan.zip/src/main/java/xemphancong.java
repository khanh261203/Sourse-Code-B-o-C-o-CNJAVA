import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.text.SimpleDateFormat;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/xemphancong")
public class xemphancong extends HttpServlet {
    private static final long serialVersionUID = 1L;

    public xemphancong() {
        super();
    }

    protected void doGet(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
        res.setContentType("text/html; charset=UTF-8");
        PrintWriter out = res.getWriter();
        res.setContentType("text/html");
        out.println("<html>"
                + "<head><link rel='stylesheet' type='text/css' href='style.css'/></head>"
                + "<body>");

        try {
            Class.forName("com.mysql.jdbc.Driver");
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/quanlykhachsan", "root", "");
            Statement stmt = con.createStatement();
            String sql = "SELECT * FROM phancong";

            ResultSet rs = stmt.executeQuery(sql);
            out.println("<table border=1 width=50% height=50%>");
            out.println("<tr><th>MaNhanVien</th><th>Ngay</th><th>Ca</th><th>TangLau</th></tr>");

            SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

            while (rs.next()) {
                String maNhanVien = rs.getString("MaNhanVien");
                String ngay = dateFormat.format(rs.getTimestamp("Ngay"));
                String ca = rs.getString("Ca");
                int tangLau = rs.getInt("TangLau");

                out.println("<tr><td>" + maNhanVien + "</td><td>" + ngay + "</td><td>" + ca + "</td><td>" + tangLau + "</td></tr>");
            }

            out.println("</table>");
            out.println("</body></html>");
            con.close();
        } catch (Exception e) {
            out.println("error");
            e.printStackTrace();
        }
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doGet(request, response);
    }
}
