import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.Timestamp;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/CapNhatChiTietDichVuServlet")
public class suachitietdichvu extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();

        String maChiTiet = request.getParameter("maChiTiet");
        int soThuTuThue = Integer.parseInt(request.getParameter("soThuTuThue"));
        String maDichVu = request.getParameter("maDichVu");
        String ngayThucHienStr = request.getParameter("ngayThucHien");
        int soLuong = Integer.parseInt(request.getParameter("soLuong"));

        try {
            // Chuyển đổi ngày từ String sang Timestamp
            SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
            Date parsedDate = dateFormat.parse(ngayThucHienStr);
            Timestamp ngayThucHien = new Timestamp(parsedDate.getTime());

            // Kết nối đến cơ sở dữ liệu (sử dụng JDBC)
            Class.forName("com.mysql.jdbc.Driver");
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/quanlykhachsan", "root", "");

            // Sử dụng PreparedStatement để cập nhật dữ liệu trong bảng chitietdichvu
            String sql = "UPDATE chitietdichvu SET SoThuTuThue=?, MaDichVu=?, NgayThucHienDichVu=?, SoLuong=? WHERE MaChiTiet=?";
            try (PreparedStatement pstmt = con.prepareStatement(sql)) {
                pstmt.setInt(1, soThuTuThue);
                pstmt.setString(2, maDichVu);
                pstmt.setTimestamp(3, ngayThucHien);
                pstmt.setInt(4, soLuong);
                pstmt.setString(5, maChiTiet);

                pstmt.executeUpdate();
            }

            // Đóng kết nối
            con.close();

            // Chuyển hướng sau khi cập nhật thành công
            response.sendRedirect("xemchitietdichvu");
        } catch (Exception e) {
            e.printStackTrace();
            out.println("Error: " + e.getMessage());
        }
    }
}
