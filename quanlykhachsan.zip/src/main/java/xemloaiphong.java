import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/xemloaiphong")
public class xemloaiphong extends HttpServlet {
    private static final long serialVersionUID = 1L;

    public xemloaiphong() {
        super();
    }

    protected void doGet(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
    	res.setContentType("text/html; charset=UTF-8");
        PrintWriter out = res.getWriter();
        res.setContentType("text/html");
        out.println("<html>"
                + "<link rel='stylesheet' type='text/css' href='style.css'/>"
                + "<body>");

        try {
            Class.forName("com.mysql.jdbc.Driver");
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/quanlykhachsan", "root", "");
            Statement stmt = con.createStatement();
            String sql = "select * from loaiphong";

            ResultSet rs = stmt.executeQuery(sql);
            out.println("<table border=1 width=50% height=50%>");
            out.println("<tr><th>MaLoaiPhong</th><th>CoMayLanh</th><th>CoTV</th><th>CoMayNuocNong</th><th>CoTuLanh</th><th>GiaThue1Ngay</th><th>GiaThue1Tuan</th></tr>");

            while (rs.next()) {
                String maLoaiPhong = rs.getString("MaLoaiPhong");
                boolean coMayLanh = rs.getBoolean("CoMayLanh");
                boolean coTV = rs.getBoolean("CoTV");
                boolean coMayNuocNong = rs.getBoolean("CoMayNuocNong");
                boolean coTuLanh = rs.getBoolean("CoTuLanh");
                double giaThue1Ngay = rs.getDouble("GiaThue1Ngay");
                double giaThue1Tuan = rs.getDouble("GiaThue1Tuan");

                out.println("<tr><td>" + maLoaiPhong + "</td><td>" + coMayLanh + "</td><td>" + coTV + "</td><td>" + coMayNuocNong + "</td><td>" + coTuLanh + "</td><td>" + giaThue1Ngay + "</td><td>" + giaThue1Tuan + "</td></tr>");
            }

            out.println("</table>");
            out.println("</html></body>");
            con.close();
        } catch (Exception e) {
            out.println("error");
        }
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doGet(request, response);
    }
}
