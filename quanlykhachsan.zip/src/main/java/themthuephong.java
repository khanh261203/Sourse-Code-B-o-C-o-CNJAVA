import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.time.LocalDateTime;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/themthuephong")
public class themthuephong extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();

        int soThuTuThue = Integer.parseInt(request.getParameter("soThuTuThue"));
        int soPhong = Integer.parseInt(request.getParameter("soPhong"));
        String maKhach = request.getParameter("maKhach");

        // Xử lý kiểu datetime
        LocalDateTime ngayNhanPhong = LocalDateTime.parse(request.getParameter("ngayNhanPhong"));
        LocalDateTime ngayTraPhong = LocalDateTime.parse(request.getParameter("ngayTraPhong"));

        double tongTienPhong = Double.parseDouble(request.getParameter("tongTienPhong"));
        double tongTienDichVu = Double.parseDouble(request.getParameter("tongTienDichVu"));

        try {
            // Kết nối đến cơ sở dữ liệu (sử dụng JDBC)
            Class.forName("com.mysql.jdbc.Driver");
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/quanlykhachsan", "root", "");

            // Sử dụng PreparedStatement để thêm dữ liệu vào bảng themthuephong
            String sql = "INSERT INTO thuephong (SoThuTuThue, SoPhong, MaKhach, NgayNhanPhong, NgayTraPhong, TongTienPhong, TongTienDichVu) VALUES (?, ?, ?, ?, ?, ?, ?)";
            try (PreparedStatement pstmt = con.prepareStatement(sql)) {
                pstmt.setInt(1, soThuTuThue);
                pstmt.setInt(2, soPhong);
                pstmt.setString(3, maKhach);
                pstmt.setObject(4, ngayNhanPhong);
                pstmt.setObject(5, ngayTraPhong);
                pstmt.setDouble(6, tongTienPhong);
                pstmt.setDouble(7, tongTienDichVu);

                pstmt.executeUpdate();
            }

            // Đóng kết nối
            con.close();

            // Chuyển hướng sau khi thêm thành công
            response.sendRedirect("xemthuephong");
        } catch (Exception e) {
            e.printStackTrace();
            out.println("Error: " + e.getMessage());
        }
    }
}
