import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/CapNhatDichVuServlet")
public class suadichvu extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();

        String maDichVu = request.getParameter("maDichVu");
        String tenDichVu = request.getParameter("tenDichVu");
        String donViTinh = request.getParameter("donViTinh");
        int dinhLuong = Integer.parseInt(request.getParameter("dinhLuong"));
        double donGia = Double.parseDouble(request.getParameter("donGia"));

        try {
            // Kết nối đến cơ sở dữ liệu (sử dụng JDBC)
            Class.forName("com.mysql.jdbc.Driver");
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/quanlykhachsan", "root", "");

            // Sử dụng PreparedStatement để cập nhật dữ liệu trong bảng dichvu
            String sql = "UPDATE dichvu SET TenDichVu=?, DonViTinh=?, DinhLuong=?, DonGia=? WHERE MaDichVu=?";
            try (PreparedStatement pstmt = con.prepareStatement(sql)) {
                pstmt.setString(1, tenDichVu);
                pstmt.setString(2, donViTinh);
                pstmt.setInt(3, dinhLuong);
                pstmt.setDouble(4, donGia);
                pstmt.setString(5, maDichVu);

                pstmt.executeUpdate();
            }

            // Đóng kết nối
            con.close();

            // Chuyển hướng sau khi cập nhật thành công
            response.sendRedirect("xemdichvu");
        } catch (Exception e) {
            e.printStackTrace();
            out.println("Error: " + e.getMessage());
        }
    }
}
