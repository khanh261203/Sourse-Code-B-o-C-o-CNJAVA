import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/themphancong")
public class themphancong extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();

        String maNhanVien = request.getParameter("maNhanVien");
        String tangLau = request.getParameter("tangLau");
        String ca = request.getParameter("ca");
        String ngayString = request.getParameter("ngay");

        try {
            // Kết nối đến cơ sở dữ liệu (sử dụng JDBC)
            Class.forName("com.mysql.jdbc.Driver");
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/quanlykhachsan", "root", "");

            // Chuyển đổi ngày từ chuỗi sang đối tượng Timestamp
            SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm");
            java.util.Date parsedDate = dateFormat.parse(ngayString);
            Timestamp ngay = new java.sql.Timestamp(parsedDate.getTime());

            // Sử dụng PreparedStatement để thêm dữ liệu vào bảng phancong
            String sql = "INSERT INTO phancong (MaNhanVien, TangLau, Ca, Ngay) VALUES (?, ?, ?, ?)";
            try (PreparedStatement pstmt = con.prepareStatement(sql)) {
                pstmt.setString(1, maNhanVien);
                pstmt.setString(2, tangLau);
                pstmt.setString(3, ca);
                pstmt.setTimestamp(4, ngay);

                pstmt.executeUpdate();
            }

            // Đóng kết nối
            con.close();

            // Chuyển hướng sau khi thêm thành công
            response.sendRedirect("xemphancong");
        } catch (Exception e) {
            e.printStackTrace();
            out.println("Error: " + e.getMessage());
        }
    }
}
