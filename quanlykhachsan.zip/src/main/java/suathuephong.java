import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.Timestamp;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/CapNhatThuePhongServlet")
public class suathuephong extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();

        int soThuTuThue = Integer.parseInt(request.getParameter("soThuTuThue"));
        int soPhong = Integer.parseInt(request.getParameter("soPhong"));
        String maKhach = request.getParameter("maKhach");
        
        // Parse ngayNhanPhong và ngayTraPhong từ String sang Timestamp
        Timestamp ngayNhanPhong = parseTimestamp(request.getParameter("ngayNhanPhong"));
        Timestamp ngayTraPhong = parseTimestamp(request.getParameter("ngayTraPhong"));

        double tongTienPhong = Double.parseDouble(request.getParameter("tongTienPhong"));
        double tongTienDichVu = Double.parseDouble(request.getParameter("tongTienDichVu"));

        try {
            // Kết nối đến cơ sở dữ liệu (sử dụng JDBC)
            Class.forName("com.mysql.jdbc.Driver");
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/quanlykhachsan", "root", "");

            // Sử dụng PreparedStatement để cập nhật dữ liệu trong bảng thuephong
            String sql = "UPDATE thuephong SET SoPhong=?, MaKhach=?, NgayNhanPhong=?, NgayTraPhong=?, TongTienPhong=?, TongTienDichVu=? WHERE SoThuTuThue=?";
            try (PreparedStatement pstmt = con.prepareStatement(sql)) {
                pstmt.setInt(1, soPhong);
                pstmt.setString(2, maKhach);
                pstmt.setTimestamp(3, ngayNhanPhong);
                pstmt.setTimestamp(4, ngayTraPhong);
                pstmt.setDouble(5, tongTienPhong);
                pstmt.setDouble(6, tongTienDichVu);
                pstmt.setInt(7, soThuTuThue);

                pstmt.executeUpdate();
            }

            // Đóng kết nối
            con.close();

            // Chuyển hướng sau khi cập nhật thành công
            response.sendRedirect("xemthuephong");
        } catch (Exception e) {
            e.printStackTrace();
            out.println("Error: " + e.getMessage());
        }
    }

    // Helper method to parse timestamp from string
    private Timestamp parseTimestamp(String dateTimeString) {
        try {
            SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm");
            Date parsedDate = dateFormat.parse(dateTimeString);
            return new Timestamp(parsedDate.getTime());
        } catch (ParseException e) {
            e.printStackTrace();
            return null;
        }
    }
}
